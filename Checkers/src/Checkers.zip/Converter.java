
public class Converter {





    /**
     * Gives a conversion from [0,4] to a letter representation for a board.
     */
    public static final char[] CONVERT = {'_', 'b', 'w', 'B', 'W', '_'};
}